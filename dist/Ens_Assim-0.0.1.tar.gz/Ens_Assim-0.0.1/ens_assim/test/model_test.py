import unittest

class TestModel(unittest.TestCase): 
    def test_ode(self):
        pass
    
    def test_rk4(self):
        pass

    def test_identity(self):
        pass