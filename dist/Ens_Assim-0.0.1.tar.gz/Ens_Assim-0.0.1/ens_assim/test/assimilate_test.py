import unittest

class TestModel(unittest.TestCase):
    def test_update_initial_condition()