import unittest

class TestAssimilate(unittest.TestCase):
    def test_no_assimilate(self):
        pass
    def test_srenkf(self):
        pass
    def test_enkf(self):
        pass
    def test_sir(self):
        pass