===========
Ens_Assim
===========

Ens_Assim provides a simple framework to perform ensemble data 
assimilation for a generic model. See the ./bin/lorenz_63_example.py
for a simple example.